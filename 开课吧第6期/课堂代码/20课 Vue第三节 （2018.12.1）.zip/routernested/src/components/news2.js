export default {
  template: `
  <div>
    新闻22222
  </div>
`
}
