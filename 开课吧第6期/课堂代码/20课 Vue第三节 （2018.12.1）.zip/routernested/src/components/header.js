export default {
  template: `
<div class="nav">
  <router-link class="nav-item" to="/index">首页</router-link>
  <router-link class="nav-item" to="/news">新闻</router-link>
</div>
`
}
