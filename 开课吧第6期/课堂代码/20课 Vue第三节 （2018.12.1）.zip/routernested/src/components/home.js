export default {
  template: `
  <div>
    首页
  </div>
`
}
