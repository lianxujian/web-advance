export default {
  template: `
  <div>
    <router-link :to="{name: 'news1'}">新闻1</router-link>
    <router-link :to="{name: 'news2'}">新闻2</router-link>
  </div>
`
}
