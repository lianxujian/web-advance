export default {
  template: `
  <div>
    新闻1111
  </div>
`
}
