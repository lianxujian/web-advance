const Router=require('koa-router');

let router=new Router();

module.exports=router.routes();
