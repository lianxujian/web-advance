export default {
  template: `
  <div>
    新闻
  </div>
`
}
