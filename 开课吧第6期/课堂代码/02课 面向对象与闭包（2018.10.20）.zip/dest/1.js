"use strict";

var a = 12;
var b = 5;

var show = function show(a, b) {
  return a + b;
};

alert(show(a, b));