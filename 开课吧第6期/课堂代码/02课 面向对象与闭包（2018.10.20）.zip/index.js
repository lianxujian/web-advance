//引入模块
/*
import * as mod1 from './mod1';

console.log(mod1);

alert(mod1.sum(mod1.a, mod1.b));

let p=new mod1.Person('blue', 18);
p.show();
*/

/*
import {a,b,c} from "./mod1";

console.log(a, b, c);
*/

import s from "./mod1";
alert(s);

/*
import("./mod2").then(mod2=>{
  alert('mod2的qq:'+mod2.qq);
}, err=>{
  alert('mod2加载失败');
});
*/
