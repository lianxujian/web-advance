var Vue = require('vue');

new Vue({
    el: 'body',
    data: {
        msg: 'Hello Vue.js!'
    }
});