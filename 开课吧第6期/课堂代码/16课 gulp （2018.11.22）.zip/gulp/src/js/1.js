let a=12;
let b=5;

//alert(a+b);

(()=>{
  let c=55;

  //alert(c);
})()
