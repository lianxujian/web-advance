window.onload=function (){
  document.body.style.background='yellow';
};
