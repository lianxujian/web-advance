let json={a: 12, b: 5};

let str='('+json+')';
console.log(str);
