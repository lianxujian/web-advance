setInterval(()=>{
  let oDate=new Date();

  console.log(oDate.getTime());
}, 1000);
