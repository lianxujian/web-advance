import React, {Component} from 'react';

class Cmp21 extends Component{
  constructor(...args){
    super(...args);
  }

  render(){
    return (
      <div>
        国际新闻
      </div>
    );
  }
}

export default Cmp21;
