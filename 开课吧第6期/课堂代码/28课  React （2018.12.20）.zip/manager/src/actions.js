export const SET_NAME='set_name';
export const ADD_AGE='add_age';
