<template>
  <div class="wrapper">
    12
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return {
      a: 16
    }
  }
}
</script>

<style scoped>

</style>
