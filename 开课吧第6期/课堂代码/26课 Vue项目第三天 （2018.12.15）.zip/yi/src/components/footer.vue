<template lang="html">
  <div class="ydc-footer">
    <div>
      <p>©2018 一点车版权所有About 公司简介  联系方法  招聘信息  客户服务  隐私政策  广告服务  网站地图  意见反馈  不良信息举报</p>
    </div>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css" scoped>
.ydc-footer {
    width: 900px;
    margin: 0 auto;
    text-align: center;
    padding: 20px 0;
}
</style>
