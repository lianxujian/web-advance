module.exports={
  DB_HOST: 'localhost',
  DB_USER: 'root',
  DB_PASS: '',
  DB_NAME: '20181101',

  ADMIN_PREFIX: '_?:L$"OPUIOSIFJ(*UPT:LKRFG'
};
