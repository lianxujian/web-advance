import {Component} from '@angular/core';

@Component({
  selector: 'AppHeader',
  templateUrl: './Header.component.html',
  styleUrls: ['./Header.component.css']
})

export class HeaderComponent {
  private name:string='blue';
}
