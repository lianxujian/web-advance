function sum(a, b) {
    return a + b;
}
console.log(sum(12, 5));
